package com.hanul.control;

import java.util.Scanner;

public class Ex14_VendingMachine {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		   
		System.out.println("---- 자판기 메뉴 ----");
		System.out.println("1.콜라   : 1250원");
		System.out.println("2.레쓰비 : 800원");
		System.out.println("3.코코팜 : 1000원");
		// 메뉴변수와 선택가능변수들을 선언한다
		
		// 투입된 금액에 따라 선택할 수 있는 음료에 선택가능 램프가 켜지도록 처리한다.
		   
		// 음료를 선택한다
		
		//거스름돈 처리하기
		
		
	}

}
