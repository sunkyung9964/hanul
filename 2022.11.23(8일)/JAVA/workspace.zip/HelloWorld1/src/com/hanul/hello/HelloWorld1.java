package com.hanul.hello;

public class HelloWorld1 {

	// main 치고 ctrl + space 바 => 자동완성
	public static void main(String[] args) {

		// syso 치고 ctrl + space 바 => 자동완성		
		System.out.println("HelloWorld!"); 
		System.out.println("안녕하세요~~ 여러분");
		System.out.println(1+2);		 

	}

}
