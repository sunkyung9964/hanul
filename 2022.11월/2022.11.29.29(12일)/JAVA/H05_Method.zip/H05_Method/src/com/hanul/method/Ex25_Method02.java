package com.hanul.method;

public class Ex25_Method02 {

	public static void main(String[] args) {

		
		
	}
	
	

}
